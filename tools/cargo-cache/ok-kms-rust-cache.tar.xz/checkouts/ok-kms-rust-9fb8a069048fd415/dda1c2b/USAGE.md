# ok-kms-rust 使用文档

OKG Aliyun KMS 的 Rust SDK，通过动态加载 `kms_linux.so` 提供密钥管理服务。

## 版本记录

| 版本 | 说明 |
|------|------|
| v1.0.0 | 初始版本，支持 `get_all_secrets` / `get_value_by_key` |

---

## 一、添加依赖

Cargo 支持直接通过 GitLab 仓库 + **tag** 引入，无需发布到 crates.io。

在你的项目 `Cargo.toml` 中添加：

```toml
[dependencies]
ok-kms-rust = { git = "git@gitlab.okg.com:okcoin-commons/ok-kms/ok-kms-rust.git", tag = "v1.0.0" }
```

> **升级版本**：只需把 `tag = "v1.0.0"` 改为新版本号，然后执行 `cargo update`。

---

## 二、环境变量

`.so` 已内嵌在 SDK 中，**无需手动部署任何文件**。

| 变量 | 是否必须 | 说明 |
|------|---------|------|
| `KMS_ENABLED` | **必须** | 设为 `true` 才启用 KMS；其他值或不设置时 `KmsClient::new()` 返回 `Disabled` 错误 |
| `KMS_SO_PATH` | 可选 | 覆盖内嵌 `.so`，指定自定义路径（通常不需要设置） |

---

## 三、代码使用

### 基础用法

```rust
use ok_kms_rust::{KmsClient, KmsError};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = KmsClient::new()?;

    // 获取所有 Secret，返回 JSON 字符串
    let all = client.get_all_secrets()?;
    println!("{}", all);

    // 按 key 获取单个值
    let db_password = client.get_value_by_key("DB_PASSWORD")?;
    println!("DB_PASSWORD = {}", db_password);

    Ok(())
}
```

### 处理 KMS_ENABLED=false 的情况

本地开发通常不启用 KMS，建议显式处理 `Disabled` 错误，回退到本地配置：

```rust
use ok_kms_rust::{KmsClient, KmsError};

fn init_kms() -> Option<KmsClient> {
    match KmsClient::new() {
        Ok(client) => {
            println!("KMS enabled");
            Some(client)
        }
        Err(KmsError::Disabled) => {
            println!("KMS disabled, using local config");
            None
        }
        Err(e) => panic!("KMS init failed: {}", e),
    }
}
```

### 多线程共享

```rust
use std::sync::Arc;
use ok_kms_rust::KmsClient;

let client = Arc::new(KmsClient::new()?);

let c = Arc::clone(&client);
std::thread::spawn(move || {
    let val = c.get_value_by_key("SOME_KEY").unwrap();
    println!("{}", val);
});
```

---

## 四、API 说明

### `KmsClient::new() -> Result<KmsClient, KmsError>`

初始化客户端。内部会：
1. 检查 `KMS_ENABLED` 是否为 `true`
2. 将内嵌的 `.so` 写出到临时目录并加载（如设置了 `KMS_SO_PATH` 则优先使用）
3. 调用 `.so` 的 `Init()` 完成初始化

### `get_all_secrets() -> Result<String, KmsError>`

获取 SecretName 下所有配置，返回 JSON 字符串，格式如下：

```json
{"DB_PASSWORD": "xxx", "REDIS_URL": "xxx"}
```

### `get_value_by_key(key: &str) -> Result<String, KmsError>`

按 key 获取单个 Secret 值，返回对应的明文字符串。

---

## 五、错误类型

| 错误 | 触发条件 |
|------|---------|
| `KmsError::Disabled` | `KMS_ENABLED` 不为 `true` |
| `KmsError::LibraryNotFound` | 找不到 `kms_linux.so` |
| `KmsError::LibraryLoad` | `.so` 加载失败（架构不匹配等） |
| `KmsError::InitFailed` | `.so` 的 `Init()` 返回失败 |
| `KmsError::StringConversion` | FFI 字符串转换异常 |
