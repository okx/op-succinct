# ok-kms-rust

OKG Aliyun KMS 的 Rust SDK，通过 FFI 调用 `kms_linux.so` / `kms_mac.so`。

## 支持平台

Linux（x86_64 / arm64），使用 `kms_linux.so`。

## 依赖

在 `Cargo.toml` 中添加：

```toml
[dependencies]
ok-kms-rust = { path = "path/to/ok-kms-rust" }
# 或发布到内部 registry 后：
# ok-kms-rust = "0.1.0"
```

## 环境变量

| 变量 | 必须 | 说明 |
|------|------|------|
| `KMS_ENABLED` | 是 | 设为 `true` 才启用 KMS；否则 `KmsClient::new()` 直接返回 `KmsError::Disabled` |
| `KMS_SO_PATH` | 否 | 指定 `kms_linux.so` 完整路径；不设则自动查找 |

## .so 文件部署

SDK 通过运行时 `dlopen` 加载 .so，**不需要**编译时链接。

`KMS_ENABLED=true` 时，按以下顺序查找 .so：

1. **`KMS_SO_PATH`**（推荐生产环境）：
   ```bash
   export KMS_SO_PATH=/opt/kms/kms_linux.so
   ```

2. **可执行文件同目录**：将 `kms_linux.so` 放到你的 binary 旁边。

3. **当前工作目录**。

## 使用

```rust
use ok_kms_rust::KmsClient;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 初始化（内部调用 Init()）
    let client = KmsClient::new()?;

    // 获取所有 Secret，返回 JSON 字符串
    let all_secrets: String = client.get_all_secrets()?;
    println!("{}", all_secrets);

    // 按 key 获取单个值
    let db_password: String = client.get_value_by_key("DB_PASSWORD")?;
    println!("DB_PASSWORD = {}", db_password);

    Ok(())
}
```

多线程场景可以用 `Arc<KmsClient>` 共享：

```rust
use std::sync::Arc;
use ok_kms_rust::KmsClient;

let client = Arc::new(KmsClient::new()?);
let c = Arc::clone(&client);
std::thread::spawn(move || {
    let val = c.get_value_by_key("SOME_KEY").unwrap();
    println!("{}", val);
});
```

## 运行示例

```bash
KMS_SO_PATH=/path/to/kms_linux.so cargo run --example basic_usage
```

## API

### `KmsClient::new() -> Result<KmsClient, KmsError>`

加载 .so 并调用 `Init()`，返回初始化完成的客户端。

### `get_all_secrets() -> Result<String, KmsError>`

调用 `GetAllSecret()`，返回 SecretName 下所有配置（JSON 格式）。

### `get_value_by_key(key: &str) -> Result<String, KmsError>`

调用 `GetSecret(key)`，返回指定 key 的值。

## 错误处理

```rust
use ok_kms_rust::KmsError;

match client.get_value_by_key("MISSING_KEY") {
    Ok(v) => println!("{}", v),
    Err(KmsError::InitFailed(msg)) => eprintln!("Init failed: {}", msg),
    Err(KmsError::LibraryNotFound(msg)) => eprintln!("Library not found: {}", msg),
    Err(e) => eprintln!("Other error: {}", e),
}
```
