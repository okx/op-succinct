//! # ok-kms-rust
//!
//! Rust SDK for OKG Aliyun KMS. Wraps `kms_linux.so` / `kms_mac.so` via FFI using `libloading`.
//!
//! ## 环境变量
//!
//! | 变量 | 必须 | 说明 |
//! |------|------|------|
//! | `KMS_ENABLED` | 是 | 设为 `true` 才会加载 .so；否则 `KmsClient::new()` 返回 `KmsError::Disabled` |
//! | `KMS_SO_PATH` | 否 | 覆盖内嵌 .so，指定自定义路径；不设则自动使用内嵌版本 |
//!
//! ## 使用示例
//!
//! ```no_run
//! use ok_kms_rust::KmsClient;
//!
//! let client = KmsClient::new().expect("KMS init failed");
//!
//! // 获取所有 Secret（返回 JSON 字符串）
//! let all = client.get_all_secrets().unwrap();
//! println!("all secrets: {}", all);
//!
//! // 按 key 获取单个值
//! let val = client.get_value_by_key("MY_DB_PASSWORD").unwrap();
//! println!("value: {}", val);
//! ```

use std::ffi::{CStr, CString};
use std::os::raw::c_char;
use std::path::PathBuf;
use std::sync::Arc;

use libloading::{Library, Symbol};
use thiserror::Error;

// ── 内嵌 .so 字节 ─────────────────────────────────────────────────────────────

#[cfg(target_os = "linux")]
const KMS_SO_BYTES: &[u8] = include_bytes!("../libs/kms_linux.so");

#[cfg(target_os = "macos")]
const KMS_SO_BYTES: &[u8] = include_bytes!("../libs/kms_mac.so");

#[cfg(not(any(target_os = "linux", target_os = "macos")))]
compile_error!("ok-kms-rust only supports Linux and macOS");

// ── 错误类型 ──────────────────────────────────────────────────────────────────

#[derive(Debug, Error)]
pub enum KmsError {
    #[error("KMS is disabled (KMS_ENABLED != true)")]
    Disabled,

    #[error("Failed to locate KMS shared library: {0}")]
    LibraryNotFound(String),

    #[error("Failed to load KMS shared library: {0}")]
    LibraryLoad(#[from] libloading::Error),

    #[error("KMS Init() returned failure: {0}")]
    InitFailed(String),

    #[error("FFI string conversion error: {0}")]
    StringConversion(String),
}

// ── 公开客户端 ────────────────────────────────────────────────────────────────

/// KMS 客户端。初始化后可安全跨线程共享（`Arc<KmsClient>`）。
pub struct KmsClient {
    // Library 必须与 KmsClient 生命周期一致，丢弃会卸载 .so。
    _lib: Arc<Library>,
    get_all_secret: unsafe extern "C" fn() -> *const c_char,
    get_secret: unsafe extern "C" fn(*const c_char) -> *const c_char,
}

// Safety: .so 中的函数是 goroutine-safe 的（CGO 导出），符号指针本身满足 Send/Sync。
unsafe impl Send for KmsClient {}
unsafe impl Sync for KmsClient {}

impl KmsClient {
    /// 创建 KmsClient。
    ///
    /// - `KMS_ENABLED` 不为 `true` 时立即返回 `Err(KmsError::Disabled)`。
    /// - 否则加载 .so 并调用 `Init()`，返回 "success" 才算初始化成功。
    pub fn new() -> Result<Self, KmsError> {
        let enabled = std::env::var("KMS_ENABLED")
            .unwrap_or_default()
            .to_lowercase();
        if enabled != "true" {
            return Err(KmsError::Disabled);
        }

        let so_path = Self::resolve_so_path()?;

        let lib = unsafe { Library::new(&so_path) }.map_err(|e| {
            KmsError::LibraryLoad(e)
        })?;

        // 调用 Init()
        let init_result = unsafe {
            let init: Symbol<unsafe extern "C" fn() -> *const c_char> =
                lib.get(b"Init\0")?;
            let ptr = init();
            if ptr.is_null() {
                return Err(KmsError::InitFailed("Init() returned null".into()));
            }
            CStr::from_ptr(ptr)
                .to_str()
                .map_err(|e| KmsError::StringConversion(e.to_string()))?
                .to_owned()
        };

        if init_result != "success" {
            return Err(KmsError::InitFailed(init_result));
        }

        // 预先解析函数指针，避免每次调用都查符号表
        let get_all_secret = unsafe {
            let sym: Symbol<unsafe extern "C" fn() -> *const c_char> =
                lib.get(b"GetAllSecret\0")?;
            *sym
        };

        let get_secret = unsafe {
            let sym: Symbol<unsafe extern "C" fn(*const c_char) -> *const c_char> =
                lib.get(b"GetSecret\0")?;
            *sym
        };

        Ok(KmsClient {
            _lib: Arc::new(lib),
            get_all_secret,
            get_secret,
        })
    }

    /// 获取 SecretName 下全部配置，返回 JSON 字符串（key-value 结构）。
    pub fn get_all_secrets(&self) -> Result<String, KmsError> {
        unsafe {
            let ptr = (self.get_all_secret)();
            ptr_to_string(ptr)
        }
    }

    /// 按 key 获取单个 Secret 值。
    pub fn get_value_by_key(&self, key: &str) -> Result<String, KmsError> {
        let c_key = CString::new(key)
            .map_err(|e| KmsError::StringConversion(e.to_string()))?;
        unsafe {
            let ptr = (self.get_secret)(c_key.as_ptr());
            ptr_to_string(ptr)
        }
    }

    // ── 私有：解析 .so 路径 ───────────────────────────────────────────────────

    fn resolve_so_path() -> Result<PathBuf, KmsError> {
        // 1. 环境变量 KMS_SO_PATH（运维覆盖用，优先级最高）
        if let Ok(path) = std::env::var("KMS_SO_PATH") {
            let p = PathBuf::from(&path);
            if p.exists() {
                return Ok(p);
            }
            return Err(KmsError::LibraryNotFound(format!(
                "KMS_SO_PATH is set to '{}' but file does not exist",
                path
            )));
        }

        // 2. 将内嵌字节写出到临时目录，直接加载
        let tmp_path = std::env::temp_dir().join("ok_kms_embedded.so");
        std::fs::write(&tmp_path, KMS_SO_BYTES).map_err(|e| {
            KmsError::LibraryNotFound(format!("Failed to extract embedded .so: {}", e))
        })?;
        Ok(tmp_path)
    }
}

// ── 工具函数 ──────────────────────────────────────────────────────────────────

unsafe fn ptr_to_string(ptr: *const c_char) -> Result<String, KmsError> {
    if ptr.is_null() {
        return Err(KmsError::StringConversion("received null pointer from KMS".into()));
    }
    CStr::from_ptr(ptr)
        .to_str()
        .map(|s| s.to_owned())
        .map_err(|e| KmsError::StringConversion(e.to_string()))
}
